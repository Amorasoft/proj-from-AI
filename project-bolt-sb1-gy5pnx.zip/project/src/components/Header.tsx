import React from 'react';
import { Menu, Moon, Star } from 'lucide-react';

export default function Header() {
  return (
    <header className="fixed w-full top-0 z-50 bg-black/10 backdrop-blur-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <Moon className="w-6 h-6 text-violet-400" />
            <span className="text-xl font-serif text-white">Wishpers of Faith</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-gray-300 hover:text-white transition-colors">Features</a>
            <a href="#about" className="text-gray-300 hover:text-white transition-colors">About</a>
            <a href="#download" className="px-4 py-2 rounded-full bg-violet-500 text-white hover:bg-violet-600 transition-colors">
              Download Now
            </a>
          </nav>
          <button className="md:hidden text-white">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
}