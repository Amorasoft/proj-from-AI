import React from 'react';
import { Sparkles, Heart, Book, Crystal } from 'lucide-react';

const features = [
  {
    icon: <Sparkles className="w-6 h-6 text-violet-400" />,
    title: 'Daily Guidance',
    description: 'Receive personalized spiritual insights and guidance tailored to your journey.'
  },
  {
    icon: <Heart className="w-6 h-6 text-violet-400" />,
    title: 'Mindful Reflections',
    description: 'Practice mindfulness with guided meditations and spiritual exercises.'
  },
  {
    icon: <Book className="w-6 h-6 text-violet-400" />,
    title: 'Sacred Journal',
    description: 'Document your spiritual journey with our beautiful journaling tools.'
  },
  {
    icon: <Crystal className="w-6 h-6 text-violet-400" />,
    title: 'Crystal Readings',
    description: 'Explore crystal meanings and receive personalized crystal recommendations.'
  }
];

export default function Features() {
  return (
    <section id="features" className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-serif text-white mb-4">Embrace Your Spiritual Path</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Discover powerful tools and insights to guide your spiritual journey
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="p-6 rounded-2xl bg-gray-800/50 backdrop-blur-lg hover:bg-gray-800/70 transition-colors">
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-serif text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}