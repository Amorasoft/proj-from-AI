import React from 'react';
import { Star, Moon, Sun } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative min-h-screen flex items-center">
      <div className="absolute inset-0 bg-gradient-to-b from-violet-900 via-indigo-900 to-black"></div>
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 animate-pulse">
          <Star className="w-4 h-4 text-yellow-200 opacity-50" />
        </div>
        <div className="absolute top-1/3 right-1/3 animate-pulse delay-75">
          <Moon className="w-6 h-6 text-violet-300 opacity-40" />
        </div>
        <div className="absolute bottom-1/4 right-1/4 animate-pulse delay-150">
          <Sun className="w-5 h-5 text-purple-300 opacity-30" />
        </div>
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-serif text-white mb-6">
            Discover Your Spiritual Journey
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Connect with your inner self through daily spiritual guidance, 
            personalized readings, and mindful reflections.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="#download" className="px-8 py-3 bg-violet-500 text-white rounded-full hover:bg-violet-600 transition-colors">
              Download Now
            </a>
            <a href="#learn-more" className="px-8 py-3 border border-violet-400 text-white rounded-full hover:bg-violet-400/10 transition-colors">
              Learn More
            </a>
          </div>
          <div className="mt-12">
            <img 
              src="https://images.unsplash.com/photo-1604881991720-f91add269bed?auto=format&fit=crop&w=800&q=80" 
              alt="App Preview" 
              className="mx-auto rounded-3xl shadow-2xl w-full max-w-md"
            />
          </div>
        </div>
      </div>
    </div>
  );
}