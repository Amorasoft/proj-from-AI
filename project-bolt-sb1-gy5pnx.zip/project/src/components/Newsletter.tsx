import React, { useState } from 'react';

export default function Newsletter() {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    console.log('Newsletter signup:', email);
    setEmail('');
  };

  return (
    <section className="py-24 bg-violet-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-serif text-white mb-4">
            Join Our Spiritual Community
          </h2>
          <p className="text-violet-200 mb-8">
            Subscribe to receive spiritual insights, exclusive content, and updates about Wishpers of Faith.
          </p>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 justify-center">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="px-6 py-3 rounded-full bg-white/10 border border-violet-400 text-white placeholder-violet-300 focus:outline-none focus:ring-2 focus:ring-violet-400"
              required
            />
            <button
              type="submit"
              className="px-8 py-3 bg-violet-500 text-white rounded-full hover:bg-violet-600 transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}